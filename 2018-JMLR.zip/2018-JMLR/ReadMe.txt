% This package is for demonstrating the following papers:
% F. Nie, Z. Hu, X. Li
% Calibrated Multi-Task Learning
and 
% Calibrated Multi-Task Regression Learning based on Low Rank Regularization.


% Author: Zhanxuan Hu (huzhanxuan@mail.nwpu.edu.cn)


% Note: 
% We would also like to thank the Dr.Jiayu Zhou for providing MATLAB softwar Malsar.

% Run: Demo_CalibrationData.m